const mongoose = require("mongoose");
const mongoUri = `mongodb+srv://nitg9631:tKIXGTlaJty72zHV@cluster0.462qmuu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`;

const connectMyDb = async () => {
  try {
    await mongoose.connect(mongoUri);
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error("Error connecting to MongoDB:", error);
    process.exit(1);
  }
};

module.exports = connectMyDb;
