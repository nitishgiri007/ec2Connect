const express = require("express");
const RegisterOrganization = require("../model/organizationSchema");
const router = express.Router();

const checkExistingOrganization = async (organization_name) => {
  try {
    const check_Organization = await RegisterOrganization.findOne({
      organization_name,
    });

    return check_Organization !== null
      ? { data: check_Organization, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const createOrganization = async (organization_name, admin_uuid) => {
  try {
    const check_existing_organization = await checkExistingOrganization(
      organization_name
    );
    if (check_existing_organization.exist) {
      return {
        message: "organization already exist",
      };
    } else {
      const newOrganization = new RegisterOrganization({
        organization_name,
        admin_uuid,
      });
      await newOrganization.save();
      return {
        success: true,
        data: newOrganization,
      };
    }
  } catch (error) {
    console.log(error);
  }
};
router.post("/api/createOrganization", async function (req, res) {
  try {
    const { organization_name, admin_uuid } = req.body;
    console.log(req.body);

    const result = await createOrganization(organization_name, admin_uuid);
    return res.status(200).json({
      success: true,
      response: result,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
});

router.get("/api/getAllOrgaizationDetails", async function (req, res) {
  try {
    const { organization_name } = req.body;

    const result = await checkExistingOrganization(organization_name);

    return res.status(200).json({
      success: result.success,
      response: result,
      id: result.data._id,
    });
  } catch (error) {}
});

module.exports = router;
