const express = require("express");
const RegisterUser = require("../model/signUpSchema");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const createJwtToken = (user) => {
  const token = jwt.sign(
    {
      uuid: user.id,
      username: user.username,
    },
    "secret_key",
    { expiresIn: "1h" }
  );

  return token;
};
const checkExisitingEmail = async (email) => {
  try {
    const email_check = await RegisterUser.findOne({ email });
    // console.log(email_check);
    return email_check !== null
      ? { data: email_check, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const cheExistingUserName = async (username) => {
  try {
    const username_check = await RegisterUser.findOne({ username });
    // console.log(username_check);
    return username_check !== null
      ? { data: username_check, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const checkExistingUser = async (email, username) => {
  try {
    const checkEmail = await checkExisitingEmail(email);
    const checkUsername = await cheExistingUserName(username);
    if (checkEmail.exist) {
      return "Email Id already exists";
    } else if (checkUsername.exist) {
      return "UserName already exists";
    } else {
      return null;
    }
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const createUser = async (
  username,
  email,
  hasPassword,
  first_name,
  last_name,
) => {
  try {
    const check_existing_user = await checkExistingUser(email, username);

    if (check_existing_user !== null) {
      return {
        message: check_existing_user,
        response: null,
      };
    } else {
      const newUser = new RegisterUser({
        username,
        email,
        password: hasPassword,
        first_name,
        last_name,
        organization_id:"",
        approved:"false",
        role:"user"
      });
      await newUser.save();
      return {
        sucess: true,
        data: newUser,
      };
    }
  } catch (error) {
    console.log(error);
  }
};

const loginUser = async (username, password) => {
  try {
    const checkUserName = await cheExistingUserName(username);
    if (checkUserName.exist) {
      const checkPassword = await bcrypt.compare(
        password,
        checkUserName.data.password
      );

      if (!checkPassword) {
        return {
          success: false,
          message: "Password is invalid",
        };
      } else {
        return {
          success: true,
          message: "Login successful",
          user: checkUserName.data,
          token: createJwtToken(checkUserName.data),
        };
      }
    } else {
      return {
        success: false,
        message: "User not found",
      };
    }
  } catch (error) {
    throw error;
  }
};

router.post("/api/user/signup", async function (req, res) {
  try {
    const { username, email, password, first_name, last_name,} =
      req.body;

    const hasPassword = await bcrypt.hash(password, 10);

    const result = await createUser(
      username,
      email,
      hasPassword,
      first_name,
      last_name,
      
    );
    return res.status(200).json({
      success: true,
      response: result,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", err: error.message });
  }
});

router.post("/api/user/login", async function (req, res) {
  // console.log(req.body);
  try {
    const { username, password } = req.body;

    const result = await loginUser(username, password);
    return res.status(200).json({
      success: result.success,
      response: result,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
});
module.exports = router;