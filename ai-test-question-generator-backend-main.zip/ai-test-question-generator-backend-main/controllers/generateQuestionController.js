const express = require("express");
const { GoogleGenerativeAI } = require("@google/generative-ai");
const verifyToken = require("../middleware/authMiddleAre");

const dotenv = require("dotenv")
const router = express.Router();
dotenv.config();


const genAI = new GoogleGenerativeAI(process.env.apiKey);

async function run() {
  // For text-only input, use the gemini-pro model
  const model = genAI.getGenerativeModel({ model: "gemini-pro" });

  const prompt = `Generate 15 Multiple Choice Type Questions which have 4 option with answer.
   Ther important point in order to generatae the question is that we generate question for the 
   B.tech student ,branch - computer Science and Engineering, semester - 3rd, subject - Data Structures and Algorithms, 
   level - modrate.
   always Genearate question according to the above mention format.
  `;


  const result = await model.generateContent(prompt);
  const response = await result.response;
  const text = response.candidates[0].content.parts[0].text;
  return text;
  console.log(text);
}

router.get("/api/generate", verifyToken, async function (req, res) {
  try {
    const answer = await run();
    res.send(answer);
  } catch (error) {
    console.error("Error sending meal plan:", error);
    res.status(500).send("Internal Server Error"); // Send a proper HTTP error status code
  }
});

module.exports = router;

// Access your API key as an environment variable (see "Set up your API key" above)

// AIzaSyCRKbufo7gC41tuGTq0lX5UJszOk_d4QoA
