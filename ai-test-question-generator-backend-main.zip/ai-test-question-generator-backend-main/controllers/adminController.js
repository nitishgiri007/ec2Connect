const express = require("express");
const RegisterAdmin = require("../model/adminSchema");
const RegisterUser = require("../model/signUpSchema");
const router = express.Router();
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const verifyToken = require("../middleware/authMiddleAre");

const createJwtToken = (user) => {
  const token = jwt.sign(
    {
      uuid: user.id,
      username: user.username,
    },
    "secret_key",
    { expiresIn: "1h" }
  );

  return token;
};
const checkExisitingEmail = async (email) => {
  try {
    const email_check = await RegisterAdmin.findOne({ email });
    // console.log(email_check);
    return email_check !== null
      ? { data: email_check, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const cheExistingUserName = async (username) => {
  try {
    const username_check = await RegisterAdmin.findOne({ username });
    // console.log(username_check);
    return username_check !== null
      ? { data: username_check, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const checkExistingUser = async (email, username) => {
  try {
    const checkEmail = await checkExisitingEmail(email);
    const checkUsername = await cheExistingUserName(username);
    if (checkEmail.exist) {
      return "Email Id already exists";
    } else if (checkUsername.exist) {
      return "UserName already exists";
    } else {
      return null;
    }
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const checkExistingUserWithUUid = async (_id) => {
  try {
    const check_user_with_uuid = await RegisterUser.findOne({ _id });

    return check_user_with_uuid !== null
      ? { data: check_user_with_uuid, exist: true }
      : { data: null, exist: false };
  } catch (error) {
    return {
      success: false,
      err: error.message,
    };
  }
};

const createUser = async (
  username,
  email,
  hasPassword,
  first_name,
  last_name
) => {
  try {
    const check_existing_user = await checkExistingUser(email, username);

    if (check_existing_user !== null) {
      return {
        message: check_existing_user,
        response: null,
      };
    } else {
      const newUser = new RegisterAdmin({
        username,
        email,
        password: hasPassword,
        first_name,
        last_name,
        organization_id: "",
        role: "admin",
      });
      await newUser.save();
      return {
        sucess: true,
        data: newUser,
      };
    }
  } catch (error) {
    console.log(error);
  }
};

const approveUser = async (_id) => {
  try {
    const checkUser = await checkExistingUserWithUUid(_id);

    if (checkUser.exist) {
      const updateUser = await updateUserStatus(_id, "approved");

      if (updateUser.success) {
        return {
          success: true,
          message: "User status updated successfully",
        };
      } else {
        return {
          success: false,
          message: "Failed to update user status",
        };
      }
    } else {
      return {
        success: false,
        message: "user not found",
      };
    }
  } catch (error) {}
};

const updateUserStatus = async (_id, status) => {
  try {
    // Find the user by UUID and update the status
    const updatedUser = await RegisterUser.findOneAndUpdate(
      { _id: _id },
      { approved: status },
      { new: true }
    );

    if (updatedUser) {
      return {
        success: true,
        user: updatedUser,
      };
    } else {
      return {
        success: false,
        message: "User not found",
      };
    }
  } catch (error) {
    console.error("Error updating user status:", error);
    return {
      success: false,
      message: "An error occurred while updating user status",
    };
  }
};

const loginUser = async (username, password) => {
  try {
    const checkUserName = await cheExistingUserName(username);
    if (checkUserName.exist) {
      const checkPassword = await bcrypt.compare(
        password,
        checkUserName.data.password
      );

      if (!checkPassword) {
        return {
          success: false,
          message: "Password is invalid",
        };
      } else {
        return {
          success: true,
          message: "Login successful",
          user: checkUserName.data,
          token: createJwtToken(checkUserName.data),
          id: checkUserName.data.id
        };
      }
    } else {
      return {
        success: false,
        message: "User not found",
      };
    }
  } catch (error) {
    throw error;
  }
};

router.post("/api/admin/signup", async function (req, res) {
  try {
    const { username, email, password, first_name, last_name } = req.body;

    const hasPassword = await bcrypt.hash(password, 10);

    const result = await createUser(
      username,
      email,
      hasPassword,
      first_name,
      last_name
    );
    return res.status(200).json({
      success: true,
      response: result,
    });
  } catch (error) {
    res
      .status(500)
      .json({ message: "Internal server error", err: error.message });
  }
});
router.post("/api/admin/login", async function (req, res) {
  // console.log(req.body);
  try {
    const { username, password } = req.body;

    const result = await loginUser(username, password);
    return res.status(200).json({
      success: result.success,
      response: result,
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({
      success: false,
      message: "Internal server error",
      error: error.message,
    });
  }
});

router.post("/api/admin/approveusers", verifyToken, async function (req, res) {
  try {
    const user_uuid = req.query.uuid;
    const result = await approveUser(user_uuid);
    return res.status(200).json({
      success: result.status,
      response: result,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
