const express = require("express");
const connectMyDb = require("./db/dbConfig");
const dotenv = require("dotenv")
const signupController = require("./controllers/userController.js")
const signupAdminController = require("./controllers/adminController.js")
const organizationController = require("./controllers/organizationController.js")
const generateQuestionController = require("./controllers/generateQuestionController.js")
const app = express();
app.use(express.json());
dotenv.config();

const port = process.env.PORT || 7000;

connectMyDb();

// app.use(loginController);
// app.use
app.use(signupController);
app.use(signupAdminController);
app.use(organizationController);
app.use(generateQuestionController);

app.listen(port, () => {
  console.log("server is started",port);
});
