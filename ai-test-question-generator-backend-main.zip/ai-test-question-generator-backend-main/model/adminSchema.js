const mongoose = require("mongoose");

const registerAdminSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
  },

  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  first_name: { type: String, required: true },
  last_name: { type: String, required: true },
  organization_id: { type: String},
  role:{type:String}
});

const RegisterAdmin = mongoose.model("RegisterAdmin", registerAdminSchema);

module.exports = RegisterAdmin;
