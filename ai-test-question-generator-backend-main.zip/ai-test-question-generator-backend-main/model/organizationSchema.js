const mongoose = require("mongoose");

const RegisterOrganizationSchema = new mongoose.Schema({
  organization_name: { type: String, required: true },
  admin_uuid: { type: String, required: true }
});

const RegisterOrganization = mongoose.model("RegisterOrganization", RegisterOrganizationSchema);

module.exports = RegisterOrganization;
